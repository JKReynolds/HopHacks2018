<?php
$verb = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['PATH_INFO'];
$routes = explode("/", $uri);

if($verb == 'POST')
{
    
    $dbhandle = new PDO("sqlite:locations.db") or die("Failed to open DB");
        
    if (!$dbhandle) die ($error);
    
    $lat = $routes[1];
    $long = $routes[2];
    $time = $routes[3];
    
    
    
    $query = "INSERT INTO records ('lat','long','time') VALUES ($lat,$long,'$time');"; //TODO:
    
    echo $query;
    $statement = $dbhandle->prepare($query);
    
    $statement->execute();
    
   // $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    
    
    // add entry into database
    
    // return success code
    
}


?>